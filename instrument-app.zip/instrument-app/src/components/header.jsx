
function Header() {
    return (
        <header className="header">
        <div className="container">
            <h1 class="logo">BangBang</h1>
        </div>
        </header>
        
    );
}

export default Header;